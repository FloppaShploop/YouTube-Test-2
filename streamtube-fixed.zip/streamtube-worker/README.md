# StreamTube — Cloudflare Worker

This version is intentionally **Worker-only**. It does not use `[assets]` or a `public/` directory, so Cloudflare's Git deployment cannot fail because it cannot detect a static-assets directory.

## Files

```text
streamtube/
├── src/
│   └── index.js
├── package.json
├── wrangler.toml
├── .gitignore
└── README.md
```

The entire UI is served by the Worker. YouTube search/metadata are requested server-side using the YouTube Data API v3. Playback uses YouTube's official embedded player.

## Deploy from Cloudflare Git

Use:

```text
Build command: npx wrangler deploy
Deploy command: npx wrangler deploy
Root directory: /
```

There is no build output directory.

## YouTube API key

Create/enable YouTube Data API v3 in Google Cloud, then configure:

```bash
npx wrangler secret put YOUTUBE_API_KEY
```

For local development, create `.dev.vars`:

```text
YOUTUBE_API_KEY="YOUR_KEY"
```

Do not commit `.dev.vars`.

## Local

```bash
npm install
npm run dev
```

## Deploy

```bash
npx wrangler login
npx wrangler secret put YOUTUBE_API_KEY
npm run deploy
```

## GitHub

Put these files at the **top level** of the repository. Do not put them inside another `streamtube/streamtube/` folder.

```bash
git init
git add .
git commit -m "Build StreamTube"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/streamtube.git
git push -u origin main
```

## Custom domain

In Cloudflare Dashboard → Workers & Pages → StreamTube → Domains & Routes, add your custom domain or subdomain.

## Important

StreamTube does not download, scrape, decrypt, proxy, or re-host YouTube media. It uses the YouTube Data API for metadata/search and YouTube's supported embedded player for playback.
