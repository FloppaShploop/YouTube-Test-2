const HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#090b0f">
<title>StreamTube</title>
<style>
:root{--bg:#090b0f;--panel:#11151b;--panel2:#171c23;--line:#252b35;--text:#f5f7fa;--muted:#98a1af;--red:#ff315c}
*{box-sizing:border-box}html{background:var(--bg);color-scheme:dark}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
button,input{font:inherit}.top{height:68px;position:sticky;top:0;z-index:20;background:rgba(9,11,15,.94);backdrop-filter:blur(16px);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px;padding:0 18px}
.logo{display:flex;align-items:center;gap:9px;color:white;text-decoration:none;font-weight:850;font-size:20px;white-space:nowrap}.logo i{font-style:normal;background:var(--red);border-radius:8px;padding:5px 8px;font-size:12px}.logo b{color:var(--red)}
.search{display:flex;max-width:700px;flex:1;margin:auto;background:var(--panel2);border:1px solid var(--line);border-radius:14px;overflow:hidden}.search input{height:44px;flex:1;min-width:0;background:none;border:0;outline:0;color:white;padding:0 15px}.search button{width:52px;border:0;background:none;color:#b5bdc9;font-size:22px;cursor:pointer}
.icon{border:0;background:none;color:#aeb6c2;font-size:21px;width:40px;height:40px;border-radius:11px;cursor:pointer}.icon:hover{background:var(--panel2);color:white}
.side{position:fixed;top:68px;left:0;bottom:0;width:225px;background:#0a0d11;border-right:1px solid var(--line);padding:15px 11px;z-index:15}.nav{display:flex;width:100%;padding:12px 13px;border:0;border-radius:11px;background:none;color:#aab2bf;text-decoration:none;cursor:pointer;text-align:left;gap:12px;font-weight:650;margin-bottom:3px}.nav:hover,.nav.active{background:var(--panel2);color:white}.nav.active{box-shadow:inset 3px 0 var(--red)}
.side h4{font-size:10px;letter-spacing:1.4px;color:#697381;margin:25px 10px 9px;text-transform:uppercase}.recent{display:grid;gap:2px}.recent button{border:0;background:none;color:#8993a1;text-align:left;border-radius:9px;padding:9px 10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.recent button:hover{background:var(--panel2);color:white}
.main{margin-left:225px;padding:28px clamp(16px,4vw,48px) 65px}.wrap{max-width:1550px;margin:auto}.hero{border:1px solid var(--line);border-radius:25px;padding:42px;min-height:235px;background:radial-gradient(circle at 85% 35%,rgba(255,49,92,.2),transparent 28%),linear-gradient(135deg,#151a22,#0e1116);display:flex;align-items:center;justify-content:space-between}.eyebrow{font-size:10px;letter-spacing:1.5px;color:#ff5878;font-weight:900;margin:0 0 9px}.hero h1{font-size:clamp(32px,5vw,57px);letter-spacing:-2.5px;line-height:.98;margin:0;max-width:680px}.hero p:not(.eyebrow){color:var(--muted);max-width:610px;line-height:1.6}.orb{width:120px;height:120px;border-radius:35px;border:1px solid rgba(255,49,92,.25);background:rgba(255,49,92,.08);display:grid;place-items:center;font-size:36px;transform:rotate(8deg)}
.heading{display:flex;align-items:end;justify-content:space-between;margin:35px 2px 17px}.heading h2{margin:0;font-size:22px}.heading p{margin:5px 0 0;color:var(--muted);font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(235px,1fr));gap:22px 17px}.card{cursor:pointer;min-width:0}.thumb{position:relative;aspect-ratio:16/9;background:var(--panel2);border:1px solid var(--line);border-radius:14px;overflow:hidden}.thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:.25s}.card:hover img{transform:scale(1.035);filter:brightness(.82)}.play{position:absolute;bottom:10px;left:10px;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;background:#000c;color:#fff;opacity:0;transition:.2s}.card:hover .play{opacity:1}.card h3{font-size:14px;line-height:1.35;margin:9px 3px 5px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.meta{color:var(--muted);font-size:11px;margin:0 3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.empty{min-height:270px;border:1px dashed var(--line);border-radius:18px;display:grid;place-items:center;align-content:center;text-align:center;color:var(--muted);padding:30px}.empty h3{color:white;margin:10px 0 4px}.empty p{margin:0;max-width:450px;line-height:1.5}
.watch{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:24px}.player{aspect-ratio:16/9;background:#000;border-radius:16px;overflow:hidden;border:1px solid var(--line)}iframe{width:100%;height:100%;border:0}.info{padding:18px 2px}.info h1{font-size:clamp(20px,3vw,29px);line-height:1.15;margin:0 0 8px}.info .sub{color:var(--muted);font-size:12px;margin-bottom:15px}.desc{color:#c2c9d3;line-height:1.65;font-size:13px;white-space:pre-line}.related{display:grid;gap:12px}.rel{display:grid;grid-template-columns:130px 1fr;gap:9px;cursor:pointer}.rel h3{font-size:12px;line-height:1.35;margin:2px 0 5px}.rel p{font-size:10px;color:var(--muted);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.modal{position:fixed;inset:0;z-index:100;background:#000b;backdrop-filter:blur(7px);display:grid;place-items:center;padding:20px}.box{width:min(520px,100%);background:#12161d;border:1px solid var(--line);border-radius:20px;padding:29px;position:relative}.box h2{margin:0 0 7px}.box>p{color:var(--muted);font-size:13px}.close{position:absolute;right:13px;top:9px;background:none;border:0;color:#aab2bd;font-size:27px;cursor:pointer}#urlForm{display:grid;gap:10px;margin-top:20px}#urlInput{height:46px;border:1px solid var(--line);background:var(--panel2);color:white;border-radius:11px;padding:0 13px;outline:0}.primary{height:46px;border:0;border-radius:11px;background:var(--red);color:white;font-weight:800;cursor:pointer}.err{color:#ff91a7;font-size:12px;min-height:19px}
.toast{position:fixed;bottom:22px;left:50%;transform:translate(-50%,20px);opacity:0;background:#181e27;border:1px solid var(--line);padding:11px 15px;border-radius:11px;transition:.2s;z-index:200;font-size:12px}.toast.show{opacity:1;transform:translate(-50%,0)}
.hidden{display:none!important}
@media(max-width:900px){.side{transform:translateX(-100%);transition:.2s}.side.open{transform:none}.main{margin-left:0}.watch{grid-template-columns:1fr}.related{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.top{height:62px;padding:0 10px}.side{top:62px}.logo span{display:none}.main{padding:18px 12px 50px}.hero{padding:29px 23px;min-height:210px}.orb{display:none}.grid{grid-template-columns:1fr 1fr;gap:17px 10px}.card h3{font-size:12px}.related{grid-template-columns:1fr}.rel{grid-template-columns:125px 1fr}}
@media(max-width:390px){.grid{grid-template-columns:1fr}.search input{font-size:13px}}
</style>
</head>
<body>
<header class="top">
<button class="icon" id="menu">☰</button>
<a class="logo" href="/"><i>▶</i><span>Stream<b>Tube</b></span></a>
<form class="search" id="search"><input id="q" placeholder="Search YouTube..." autocomplete="off"><button>⌕</button></form>
<button class="icon" id="urlBtn">↗</button>
</header>
<aside class="side" id="side">
<button class="nav active" id="homeBtn">⌂ &nbsp; Home</button>
<button class="nav" id="popularBtn">✦ &nbsp; Popular</button>
<button class="nav" id="watchUrlBtn">🔗 &nbsp; Watch by URL</button>
<h4>Recent searches</h4><div class="recent" id="recent"></div>
</aside>
<main class="main"><div class="wrap">
<section id="home">
<div class="hero"><div><p class="eyebrow">YOUTUBE SEARCH</p><h1>Find something worth watching.</h1><p>Search YouTube and watch through YouTube's official embedded player.</p></div><div class="orb">▶</div></div>
<div class="heading"><div><h2 id="homeTitle">Featured</h2><p id="homeSub">Search for videos to get started.</p></div></div>
<div id="homeGrid" class="grid"></div>
<div id="homeEmpty" class="empty"><div><div style="font-size:35px;color:#ff315c">⌕</div><h3>Nothing here yet</h3><p>Your recent searches will appear here.</p></div></div>
</section>
<section id="results" class="hidden"><div class="heading"><div><p class="eyebrow">SEARCH RESULTS</p><h2 id="resultsTitle"></h2></div><p id="count"></p></div><div id="resultsGrid" class="grid"></div><div id="resultsEmpty" class="empty hidden"><div><h3>No videos found</h3><p>Try another search.</p></div></div></section>
<section id="watch" class="hidden"><div class="watch"><div><div class="player"><iframe id="player" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div><div class="info" id="info"></div></div><aside><div class="heading" style="margin-top:0"><h2>Related</h2></div><div id="related" class="related"></div></aside></div></section>
</div></main>
<div class="modal hidden" id="modal"><div class="box"><button class="close" id="close">×</button><p class="eyebrow">WATCH DIRECTLY</p><h2>Paste a YouTube link</h2><p>Enter a YouTube URL or an 11-character video ID.</p><form id="urlForm"><input id="urlInput" placeholder="https://www.youtube.com/watch?v=..." autocomplete="off"><button class="primary">Watch video</button></form><div class="err" id="err"></div></div></div>
<div class="toast" id="toast"></div>
<script>
const $=s=>document.querySelector(s);
const state={recent:JSON.parse(localStorage.getItem("st_recent")||"[]"),timer:null};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function date(s){if(!s)return"";let d=new Date(s);return isNaN(d)?"":d.toLocaleDateString(undefined,{dateStyle:"medium"})}
function num(v){if(v==null)return"";return Intl.NumberFormat(undefined,{notation:"compact",maximumFractionDigits:1}).format(Number(v))}
function save(q){q=q.trim();if(!q)return;state.recent=[q,...state.recent.filter(x=>x.toLowerCase()!=q.toLowerCase())].slice(0,8);localStorage.setItem("st_recent",JSON.stringify(state.recent));renderRecent()}
function renderRecent(){$("#recent").innerHTML=state.recent.length?state.recent.map(q=>`<button data-q="${esc(q)}">${esc(q)}</button>`).join(""):`<span style="color:#59616e;font-size:11px;padding:8px 10px">No searches yet.</span>`;document.querySelectorAll("#recent button").forEach(b=>b.onclick=()=>search(b.dataset.q))}
function card(v){return `<article class="card" data-id="${esc(v.id)}"><div class="thumb"><img src="${esc(v.thumbnail)}" loading="lazy" alt=""><span class="play">▶</span></div><h3>${esc(v.title)}</h3><p class="meta">${esc(v.channelTitle)}${v.publishedAt?" • "+esc(date(v.publishedAt)):""}</p></article>`}
function rel(v){return `<article class="rel" data-id="${esc(v.id)}"><div class="thumb"><img src="${esc(v.thumbnail)}" loading="lazy" alt=""></div><div><h3>${esc(v.title)}</h3><p>${esc(v.channelTitle)}</p></div></article>`}
function bind(root){root.querySelectorAll("[data-id]").forEach(x=>x.onclick=()=>openVideo(x.dataset.id))}
function view(n){$("#home").classList.toggle("hidden",n!="home");$("#results").classList.toggle("hidden",n!="results");$("#watch").classList.toggle("hidden",n!="watch");if(n=="home")$("#homeBtn").classList.add("active");else $("#homeBtn").classList.remove("active")}
async function api(path){let r=await fetch(path);let d={};try{d=await r.json()}catch{}if(!r.ok)throw Error(d.error||"Request failed");return d}
async function search(q){q=String(q||"").trim();if(!q)return;$("#q").value=q;save(q);view("results");$("#resultsTitle").textContent=q;$("#count").textContent="";$("#resultsGrid").innerHTML=`<div class="empty"><p>Searching YouTube…</p></div>`;$("#resultsEmpty").classList.add("hidden");try{let d=await api("/api/search?q="+encodeURIComponent(q));$("#resultsGrid").innerHTML=(d.items||[]).map(card).join("");$("#count").textContent=(d.items||[]).length+" results";if(!d.items?.length)$("#resultsEmpty").classList.remove("hidden");bind($("#resultsGrid"))}catch(e){$("#resultsGrid").innerHTML="";$("#resultsEmpty").classList.remove("hidden");$("#resultsEmpty h3").textContent="Search unavailable";$("#resultsEmpty p").textContent=e.message}}
async function openVideo(id){if(!/^[A-Za-z0-9_-]{11}$/.test(id||""))return toast("Invalid YouTube video ID.");history.pushState({id},"","/watch/"+id);view("watch");scrollTo(0,0);$("#player").src="https://www.youtube.com/embed/"+encodeURIComponent(id)+"?rel=0&playsinline=1&origin="+encodeURIComponent(location.origin);$("#info").innerHTML="<p>Loading video information…</p>";$("#related").innerHTML="<p style='color:#98a1af'>Loading…</p>";let [a,b]=await Promise.allSettled([api("/api/video?id="+id),api("/api/related?id="+id)]);if(a.status=="fulfilled"){let v=a.value;$("#info").innerHTML=`<h1>${esc(v.title)}</h1><div class="sub">${esc([v.channelTitle,v.views?num(v.views)+" views":"",v.publishedAt?date(v.publishedAt):""].filter(Boolean).join(" • "))}</div><div class="desc">${esc(v.description||"No description available.")}</div>`}else $("#info").innerHTML="<h1>Video</h1><div class='sub'>YouTube player loaded directly.</div>";if(b.status=="fulfilled"){let items=b.value.items||[];$("#related").innerHTML=items.length?items.map(rel).join(""):"<p style='color:#98a1af'>No related videos found.</p>";bind($("#related"))}else $("#related").innerHTML="<p style='color:#98a1af'>Related videos unavailable.</p>"}
async function openInput(s){try{let d=await api("/api/parse?input="+encodeURIComponent(s));if(!d.id)throw Error("Invalid YouTube URL or video ID.");closeModal();openVideo(d.id)}catch(e){$("#err").textContent=e.message}}
function modal(){ $("#modal").classList.remove("hidden");$("#err").textContent="";$("#urlInput").value="";setTimeout(()=>$("#urlInput").focus(),30)}
function closeModal(){$("#modal").classList.add("hidden")}
function toast(s){let x=$("#toast");x.textContent=s;x.classList.add("show");clearTimeout(state.timer);state.timer=setTimeout(()=>x.classList.remove("show"),2300)}
function home(){renderRecent();if(!state.recent.length){$("#homeGrid").innerHTML="";$("#homeEmpty").classList.remove("hidden");return}$("#homeEmpty").classList.add("hidden");$("#homeTitle").textContent="Recent searches";$("#homeSub").textContent="Pick up where you left off.";$("#homeGrid").innerHTML=state.recent.slice(0,4).map(q=>`<article class="card" data-search="${esc(q)}"><div class="thumb" style="display:grid;place-items:center;background:#151a22"><span style="font-size:36px;color:#ff315c">⌕</span></div><h3>${esc(q)}</h3><p class="meta">Search YouTube again</p></article>`).join("");document.querySelectorAll("[data-search]").forEach(x=>x.onclick=()=>search(x.dataset.search))}
$("#search").onsubmit=e=>{e.preventDefault();search($("#q").value)};$("#menu").onclick=()=>$("#side").classList.toggle("open");$("#urlBtn").onclick=modal;$("#watchUrlBtn").onclick=modal;$("#close").onclick=closeModal;$("#modal").onclick=e=>{if(e.target==$("#modal"))closeModal()};$("#urlForm").onsubmit=e=>{e.preventDefault();openInput($("#urlInput").value)};$("#homeBtn").onclick=()=>{history.pushState({},"","/");view("home");home()};$("#popularBtn").onclick=()=>search("popular videos");window.onpopstate=()=>{let m=location.pathname.match(/^\\/watch\\/([A-Za-z0-9_-]{11})$/);m?openVideo(m[1]):(view("home"),home())};home();
</script>
</body></html>`;

function json(data,status=200){
  return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json;charset=UTF-8","cache-control":"no-store"}});
}
function idFrom(input){
  if(!input)return null;
  let s=String(input).trim();
  if(/^[A-Za-z0-9_-]{11}$/.test(s))return s;
  try{
    let u=new URL(s),h=u.hostname.toLowerCase().replace(/^www\./,"");
    if(h==="youtu.be"){let id=u.pathname.split("/").filter(Boolean)[0];return /^[A-Za-z0-9_-]{11}$/.test(id||"")?id:null}
    if(["youtube.com","m.youtube.com","music.youtube.com","youtube-nocookie.com"].includes(h)){
      let v=u.searchParams.get("v");if(/^[A-Za-z0-9_-]{11}$/.test(v||""))return v;
      let p=u.pathname.split("/").filter(Boolean);if(["embed","shorts","live","v"].includes(p[0]))return /^[A-Za-z0-9_-]{11}$/.test(p[1]||"")?p[1]:null;
    }
  }catch{}
  return null;
}
const clean=(x,n=5000)=>String(x||"").replace(/\s+/g," ").trim().slice(0,n);
function item(x){
  let id=x?.id?.videoId||x?.id,s=x?.snippet||{};if(!/^[A-Za-z0-9_-]{11}$/.test(id||""))return null;
  return{id,title:clean(s.title,300),description:clean(s.description,1200),channelTitle:clean(s.channelTitle,200),channelId:s.channelId||"",publishedAt:s.publishedAt||null,thumbnail:s.thumbnails?.maxres?.url||s.thumbnails?.high?.url||s.thumbnails?.medium?.url||`https://i.ytimg.com/vi/${id}/hqdefault.jpg`};
}
async function yt(path,params,env){
  if(!env.YOUTUBE_API_KEY)throw Error("YOUTUBE_API_KEY is not configured.");
  let u=new URL("https://www.googleapis.com/youtube/v3/"+path);Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));u.searchParams.set("key",env.YOUTUBE_API_KEY);
  let r=await fetch(u);let text=await r.text();if(!r.ok){let msg="YouTube API request failed.";try{msg=JSON.parse(text)?.error?.message||msg}catch{}throw Error(msg)}return JSON.parse(text);
}
async function api(req,env){
  let u=new URL(req.url);
  if(u.pathname==="/api/parse")return json({id:idFrom(u.searchParams.get("input"))});
  if(u.pathname==="/api/search"){let q=clean(u.searchParams.get("q"),120);if(!q)return json({error:"Enter a search term."},400);let d=await yt("search",{part:"snippet",q,type:"video",maxResults:String(Math.min(Number(u.searchParams.get("limit"))||18,25)),regionCode:"US",safeSearch:"moderate",videoEmbeddable:"true"},env);return json({items:(d.items||[]).map(item).filter(Boolean),nextPageToken:d.nextPageToken||null})}
  if(u.pathname==="/api/video"){let id=idFrom(u.searchParams.get("id"));if(!id)return json({error:"Invalid video ID."},400);let d=await yt("videos",{part:"snippet,contentDetails,statistics",id},env),v=d.items?.[0];if(!v)return json({error:"Video not found."},404);return json({...item(v),views:v.statistics?.viewCount||null,likes:v.statistics?.likeCount||null,duration:v.contentDetails?.duration||null})}
  if(u.pathname==="/api/related"){let id=idFrom(u.searchParams.get("id"));if(!id)return json({error:"Invalid video ID."},400);let d=await yt("videos",{part:"snippet",id},env),title=d.items?.[0]?.snippet?.title||"";let q=clean(title.replace(/[^\p{L}\p{N}\s-]/gu,"").split(/\s+/).slice(0,8).join(" "),120);if(!q)return json({items:[]});let r=await yt("search",{part:"snippet",q,type:"video",maxResults:"9",regionCode:"US",safeSearch:"moderate",videoEmbeddable:"true"},env);return json({items:(r.items||[]).map(item).filter(Boolean).filter(x=>x.id!==id).slice(0,8)})}
  return json({error:"API route not found."},404);
}
export default {async fetch(request,env){
  let u=new URL(request.url);
  if(u.pathname.startsWith("/api/")){
    if(request.method!=="GET")return json({error:"Method not allowed."},405);
    try{return await api(request,env)}catch(e){return json({error:e.message||"Server error."},500)}
  }
  return new Response(HTML,{headers:{"content-type":"text/html;charset=UTF-8","cache-control":"public,max-age=60"}});
}};
